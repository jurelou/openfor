# pragma: no cover
TESTING = True
LOADERS_FOR_DYNACONF = [
    "dynaconf.loaders.env_loader",
    # 'dynaconf.loaders.redis_loader'
]
